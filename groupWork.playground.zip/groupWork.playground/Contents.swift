import Cocoa




extension chargedParticle: DifferentiableAndTurnable{
    
}







EulerStep(pendulum: chargedParticle(x: 5, y: 5, z: 5, xdot: 5, ydot: 0, zdot: 0, particleMass: 2, particleCharge: 1, ElectricfieldStrengthx: 0, ElectricfieldStrengthy: 0, ElectricfieldStrengthz: 0, MagneticFieldStrengthx: 0, MagneticFieldStrengthy: 0, MagneticFieldStrengthz: -10), initialValue_Independant: 0.0, dt: 0.1, number_of_steps: 2)
