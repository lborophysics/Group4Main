import Foundation




public struct chargedParticle{
    
    var x: Double
    var y: Double
    var z: Double
    
    var xdot: Double
    var ydot: Double
    var zdot: Double
    
    let particleMass: Double
    let particleCharge: Double
    let ElectricfieldStrengthx: Double
    let ElectricfieldStrengthy: Double
    let ElectricfieldStrengthz: Double
    
    
    let MagneticFieldStrengthx: Double
    let MagneticFieldStrengthy: Double
    let MagneticFieldStrengthz: Double
    
    
    public init(x: Double, y: Double, z: Double, xdot: Double, ydot: Double, zdot: Double, particleMass: Double, particleCharge: Double,  ElectricfieldStrengthx: Double, ElectricfieldStrengthy:Double, ElectricfieldStrengthz:Double, MagneticFieldStrengthx: Double, MagneticFieldStrengthy: Double, MagneticFieldStrengthz: Double){
    
    
    self.x = x
    self.y = y
    self.z = z
    
    self.xdot = xdot
    self.ydot = ydot
    self.zdot = zdot
    
    
    self.particleMass = particleMass
        
        
    self.particleCharge = particleCharge
        
    self.ElectricfieldStrengthx = ElectricfieldStrengthx
    self.ElectricfieldStrengthy = ElectricfieldStrengthy
    self.ElectricfieldStrengthz = ElectricfieldStrengthz
    
    
    self.MagneticFieldStrengthx = MagneticFieldStrengthx
    self.MagneticFieldStrengthy = MagneticFieldStrengthy
    self.MagneticFieldStrengthz = MagneticFieldStrengthz
    
    
    
    
}

public func InitialConditionsIntoVectorForm(_ a: chargedParticle)-> DoubleVector{

    let x = a.x
    let y = a.y
    let z = a.z
    let q = a.xdot
    let p = a.ydot
    let w = a.zdot

return DoubleVector(dimensionLength: [x, y, z, q, p, w])
}


public func dydt(y: DoubleVector, system: chargedParticle)-> DoubleVector {

    
    
    var y_out = DoubleVector(dimensionLength: [0.0,0.0,0.0,0.0,0.0,0.0])
    
    
    
    
    let q = system.particleCharge
    let m = system.particleMass
    let Ex = system.ElectricfieldStrengthx
    let Ey = system.ElectricfieldStrengthy
    let Ez = system.ElectricfieldStrengthz
    
    
    let Bx = system.MagneticFieldStrengthx
    let By = system.MagneticFieldStrengthy
    let Bz = system.MagneticFieldStrengthz

    
    let E = DoubleVector(dimensionLength: [Ex, Ey, Ez])
    
    
    let B = DoubleVector(dimensionLength: [Bx, By, Bz])
    
    
  

    
        var xdot = y.dimensionLength[3]
    
        var ydot = y.dimensionLength[4]
    
        var zdot = y.dimensionLength[5]
    
    
    
    var f2 = DoubleVector(dimensionLength: [xdot, ydot, zdot])
    
    
    var a = f2.crossproduct(B)
    
    var b = E + a
    
    var c = q * b

    let p = c / m
    
    
    y_out[0] = xdot
    
    y_out[1] = ydot
    
    y_out[2] = zdot
    
    
    y_out[3] = p.dimensionLength[0]
    
    y_out[4] = p.dimensionLength[1]
    
    y_out[5] = p.dimensionLength[2]
    
    
    
    
    
    
    
    
        //y out 0 = velocity
        // y out 1 = acceleration

    
    
    
    return DoubleVector(dimensionLength: [y_out[0], y_out[1],y_out[2], y_out[3], y_out[4], y_out[5]] )
                                         
                                          
                                          
                                          
                                          
                                          
    }


    
    
}
    









