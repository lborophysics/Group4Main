import Foundation

public func EulerStep < T : DifferentiableAndTurnable>(pendulum: T, initialValue_Independant: Double, dt: Double, number_of_steps: Int)-> [(Double, DoubleVector)]{


    var results: [(Double, DoubleVector)] = []





    var fx = pendulum.InitialConditionsIntoVectorForm( pendulum)

    var t = initialValue_Independant

    let p = number_of_steps


            for _ in 0 ..< p{


                let derivative = pendulum.dydt(y: fx, system: pendulum)

                fx = fx  + derivative * dt

                t = t + dt

                results.append((t, fx))
            }

    
return results
}
