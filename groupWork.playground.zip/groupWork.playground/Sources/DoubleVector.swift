import Foundation


public struct DoubleVector {

  public var dimensionLength: [Double]
    


    public init(dimensionLength: [Double]) {
         self.dimensionLength = dimensionLength
     }

    
    public  subscript(index: Int) -> Double {
             get {
                 return dimensionLength[index]
             }
             set(newValue) {
                 dimensionLength[index] = newValue
             }
         }


    func printValues(){

        for i in 0 ..< dimensionLength.count {

            print("\(dimensionLength[i]) d\(i+1) " )

        }


    }









   public static func *(_ lhs: Double, _ rhs: DoubleVector)-> DoubleVector{

        var copy = rhs.dimensionLength

        for i in 0 ..< copy.count {

            copy[i] = copy[i] * lhs
        }

        return DoubleVector(dimensionLength: copy)

    }













   public static func *(_ lhs: DoubleVector, _ rhs: Double)-> DoubleVector{

        var copy = lhs.dimensionLength

        for i in 0 ..< copy.count {

            copy[i] =  rhs * copy[i]
        }

        return DoubleVector(dimensionLength: copy)

    }






   public static func +(_ lhs: DoubleVector, _ rhs: DoubleVector)-> DoubleVector{


        var copy1 = rhs.dimensionLength
        var copy2 = lhs.dimensionLength


        while copy2.count < rhs.dimensionLength.count {
            copy2.append(0.0) }
        while rhs.dimensionLength.count < lhs.dimensionLength.count {
            copy1.append(0.0)}


        var copy = lhs.dimensionLength



        for i in 0 ..< copy2.count {

            copy[i] = copy1[i] + copy2[i]

        }

        return DoubleVector(dimensionLength: copy)

    }

    public static func -(_ lhs: DoubleVector, _ rhs: DoubleVector)-> DoubleVector{


         var copy1 = rhs.dimensionLength
         var copy2 = lhs.dimensionLength


         while copy2.count < rhs.dimensionLength.count {
             copy2.append(0.0) }
         while rhs.dimensionLength.count < lhs.dimensionLength.count {
             copy1.append(0.0)}


         var copy = lhs.dimensionLength



         for i in 0 ..< copy2.count {

             copy[i] = copy1[i] - copy2[i]

         }

         return DoubleVector(dimensionLength: copy)

     }






    public static func /(_ lhs: DoubleVector, _ rhs: Double)-> DoubleVector{

        var copy = lhs.dimensionLength

        for i in 0 ..< copy.count {

            copy[i] =  copy[i] / rhs
        }

        return DoubleVector(dimensionLength: copy)

    }




    public func crossproduct(_ rhs: DoubleVector) -> DoubleVector {
        
        var x1 = self.dimensionLength[0] //a
        var y1 = self.dimensionLength[1]  //b
        var z1 = self.dimensionLength[2] //c

        var x2 = rhs.dimensionLength[0]//d
        var y2 = rhs.dimensionLength[1] //e
        var z2 = rhs.dimensionLength[2] //f
        
   // x: b * f - c * e,
    //y: c * d - a * f,
    
    //z: a * e - b * d)
        
        
        var x = y1 * z2 - z1 * y2
        
        
        var y = z1 * x2 - x1 * z2
        
        var z = x1 * y2 - y1 * x2
        
        
        return DoubleVector(dimensionLength: [x, y, z])
        
        
    }





}




//
//
//public postfix func crossproduct(_ lhs: DoubleVector,_ rhs: DoubleVector) -> DoubleVector {
//
//    let x1 = lhs.dimensionLength[0] //a
//    let y1 = lhs.dimensionLength[1]  //b
//    let z1 = lhs.dimensionLength[2] //c
//
//    let x2 = rhs.dimensionLength[0]//d
//    let y2 = rhs.dimensionLength[1] //e
//    let z2 = rhs.dimensionLength[2] //f
