import Foundation



public protocol differentiable{

  func dydt(y: DoubleVector, system: Self)-> DoubleVector

}
 

public protocol TurnInitialConditionsToVectorForm{
    
    func InitialConditionsIntoVectorForm(_ : Self) -> DoubleVector
}




public protocol DifferentiableAndTurnable: differentiable,
                                           TurnInitialConditionsToVectorForm {
}
