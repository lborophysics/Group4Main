import Cocoa

var qtime = 0
var MaxTime = 120



//public struct Grid {
//    let rows: Int
//    let columns: Int
//    private var data: [[Double]] //Double array
//    
//    init(rows: Int, columns: Int, initialValue: Double) {
//        self.rows = rows
//        self.columns = columns
//        self.data = Array(repeating: Array(repeating: initialValue, count: columns), count: rows) //nested array
//    }
//    
//    subscript(row: Int, column: Int) -> Double {
//        get {
//            precondition(row >= 0 && row < rows, "Index out of range")
//            precondition(column >= 0 && column < columns, "Index out of range")
//            return data[row][column]
//        }
//        set {
//            precondition(row >= 0 && row < rows, "Index out of range")
//            precondition(column >= 0 && column < columns, "Index out of range")
//            data[row][column] = newValue
//        }
//    }
//}



let numberOfRows = 81

let numberOfColumns = 101

let courant = 1.0

let imp0 = 377.0

let pi = Double.pi



//prebiously width = 10, refers to time step with??

// in previous examples delay = 30

//func ezINC(qtime: Double, location: Double, width: Double, delay: Double)-> Double { // travelling wave implementation of gaussianpulse ( ref page 100)
//
//    var a = qtime - delay
//    var b  = location / courant
//    var c = a - b
//    var d = c / width
//
//    var p = pow(d, 2)
//
//
//
//    return exp(-p)
//
//
//}


func ezINCricker(qtime: Int, location: Double, ppw: Double)-> Double { // travelling wave implementation of gaussianpulse ( ref page 100)
    
    var arg: Double = 0
    
    var qtimeDouble = Double(qtime)

    
    var a = courant * qtimeDouble - location
    var b  = ppw - 1.0
    
    var c = a / b
    
    arg = pi * c
    
    
    arg = arg * arg
    
    
    var d = 1.0
    
    var e = 2.0 * arg
    
    var f = d - e
    
   var g = exp(-arg)
    
    
    
    return f * g
    
    
}




public var Ez = Grid(columns: numberOfColumns, rows: numberOfRows, initialValue: 0.0)


var Hx = Grid(columns: numberOfColumns , rows: numberOfRows - 1, initialValue: 0.0)

var Hy = Grid(columns: numberOfColumns - 1, rows: numberOfRows , initialValue: 0.0)


var Chxe = Grid(columns: numberOfColumns , rows: numberOfRows - 1, initialValue: 0.0)

var Chye = Grid(columns: numberOfColumns - 1, rows: numberOfRows , initialValue: 0.0)

var Ceze = Grid(columns: numberOfColumns, rows: numberOfRows, initialValue: 0.0)



var Chxh = Grid(columns: numberOfColumns , rows: numberOfRows - 1, initialValue: 0.0)

var Chyh = Grid(columns: numberOfColumns - 1, rows: numberOfRows, initialValue: 0.0)

var Cezh = Grid(columns: numberOfColumns, rows: numberOfRows, initialValue: 0.0)












    
    
    
    
    
    
    
    
let courantximp = courant * imp0
    
    
    
    //electric field COEFFICIENTS updates
    
    for m in 0..<numberOfColumns{
        for n in 0..<numberOfRows{
            Ceze[m,n] = 1.0
            Cezh[m,n] = courantximp
            
        }
        
    }
    
  
    
    //MAgnetic field COEFFICIENTS updates
    
    let courantDIVimp = courant / imp0
    
    for m in 0..<numberOfColumns{
        for n in 0..<numberOfRows - 1{
            
            Chxh[m,n] = 1.0
            Chxe[m,n] = courantDIVimp
            
        }
    }
    
    for m in 0..<numberOfColumns - 1{
        for n in 0..<numberOfRows{
            
            Chyh[m,n] = 1.0
            Chye[m,n] = courantDIVimp
            
        }
        
    }
    
    ///===================
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    







//let fileout = FileWriter(fileName: "Electro.dat")
//fileout.writeBinaryData(data: "")

for qtime in 0..<MaxTime {
    
    
    //electric update eq
    
//    for m in 1..<numberOfRows - 1{ // refer to program 8.9
//
//        for n in 1..<numberOfColumns - 1 {
//
//           // Ez[m, n] = Ceze[m, n] * Ez[m, n] + Cezh[m, n] * ((Hy[m, n] - Hy[m - 1, n]) - (Hx[m, n] - Hx[m, n - 1]))
//
//
//            var a = Ceze[m, n] * Ez[m, n]
//
//            var b = (Hy[m, n] - Hy[m - 1, n])
//
//            var c = (Hx[m, n] - Hx[m, n - 1])
//
//            var d = b - c
//
//            var e = Cezh[m, n] * d
//
//
//
//            Ez[m, n] = a + e
//
//
//
//        }
//    }
//
    
    
//    Ez[numberOfRows / 2, numberOfColumns / 2] = ezINCricker(qtime: qtime, location: 0.0, ppw: 20)
//
//
//
    // hx update equation

    for m in 0..<numberOfColumns {

        for n in 0..<numberOfRows - 1{

            // Hx[m, n] = Chxh[m, n] * Hx[m, n] - Chxe[m, n] * (Ez[m, n + 1] - Ez[m, n])


            var a = Chxh[m, n] * Hx[m, n]

            var b = Ez[m, n + 1] - Ez[m, n]

            var c = Chxe[m, n] * b

            var d = a - c




            Hx[m, n] = d





        }
    }


    
    // hy update equation
    for m in 0..<numberOfColumns - 1{
        
        for n in 0..<numberOfRows {
            
           // Hy[m, n] = Chyh[m, n] * Hy[m, n] + Chye[m, n] * (Ez[m + 1, n] - Ez[m, n])
            
            
            var a = Chyh[m, n] * Hy[m, n]
            
            var b = Ez[m + 1, n] - Ez[m, n]
            
            var c = Chye[m , n] * b
            
            var d = a + c
            
            
            Hy[m, n] = d
            
            
            
        }
    }
    
    
    
    
    for m in 1..<numberOfColumns - 1{ // refer to program 8.9
        
        for n in 1..<numberOfRows - 1 {
            
           // Ez[m, n] = Ceze[m, n] * Ez[m, n] + Cezh[m, n] * ((Hy[m, n] - Hy[m - 1, n]) - (Hx[m, n] - Hx[m, n - 1]))
            
            
            var a = Ceze[m, n] * Ez[m, n]
            
            var b = (Hy[m, n] - Hy[m - 1, n])
            
            var c = (Hx[m, n] - Hx[m, n - 1])
            
            var d = b - c
            
            var e = Cezh[m, n] * d
            
            
            
            Ez[m, n] = a + e
            
            
            
        }
    }



   Ez[(numberOfColumns - 1) / 2, (numberOfRows - 1) / 2] = ezINCricker(qtime: qtime, location: 0.0, ppw: 20)


    snapshot2d(qtime: qtime, ez: Ez)

  //  print( Ez[50, 40])
    


}

