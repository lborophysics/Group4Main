import Foundation

//

// the below is when m = columns = x axis. and n = rows  = y axis
//public struct Grid {
//    let rows: Int
//    let columns: Int
//    private var data: [[Double]] //Double array
//
//    public init(rows: Int, columns: Int, initialValue: Double) {
//        self.rows = rows
//        self.columns = columns
//        self.data = Array(repeating: Array(repeating: initialValue, count: columns), count: rows) //nested array
//    }
//
//   public subscript(row: Int, column: Int) -> Double {
//        get {
//            precondition(row >= 0 && row < rows, "Index out of range")
//            precondition(column >= 0 && column < columns, "Index out of range")
//            return data[row][column]
//        }
//        set {
//            precondition(row >= 0 && row < rows, "Index out of range")
//            precondition(column >= 0 && column < columns, "Index out of range")
//            data[row][column] = newValue
//        }
//    }
//}
//



//
//public struct Grid {
//    let rows: Int
//    let columns: Int
//    private var data: [[Double]] // Double array
//
//    public init(rows: Int, columns: Int, initialValue: Double) {
//        self.rows = rows
//        self.columns = columns
//        self.data = Array(repeating: Array(repeating: initialValue, count: rows), count: columns) // Nested array
//    }
//
//    public subscript(column: Int, row: Int) -> Double { // Swap column and row
//        get {
//            precondition(column >= 0 && column < columns, "Index out of range") // Swap column and row
//            precondition(row >= 0 && row < rows, "Index out of range") // Swap column and row
//            return data[column][row] // Swap column and row
//        }
//        set {
//            precondition(column >= 0 && column < columns, "Index out of range") // Swap column and row
//            precondition(row >= 0 && row < rows, "Index out of range") // Swap column and row
//            data[column][row] = newValue // Swap column and row
//        }
//    }
//}


public struct Grid {
    let columns: Int // Number of columns
    let rows: Int // Number of rows
    private var data: [[Double]] // Double array
    
    public init(columns: Int, rows: Int, initialValue: Double) { // Swap columns and rows in the init parameters
        self.columns = columns
        self.rows = rows
        self.data = Array(repeating: Array(repeating: initialValue, count: columns), count: rows) // Nested array
    }
    
    public subscript(column: Int, row: Int) -> Double { // Swap column and row in the subscript
        get {
            precondition(column >= 0 && column < columns, "Index out of range") // Swap column and row
            precondition(row >= 0 && row < rows, "Index out of range") // Swap column and row
            return data[row][column]
        }
        set {
            precondition(column >= 0 && column < columns, "Index out of range") // Swap column and row
            precondition(row >= 0 && row < rows, "Index out of range") // Swap column and row
            data[row][column] = newValue
        }
    }
}
