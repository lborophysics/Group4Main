import Foundation

public func ezINCricker(qtime: Int, location: Double, ppw: Double)-> Double { // travelling wave implementation of gaussianpulse ( ref page 100)
    
//    guard ppw > 0 else {
//           return nil // Return nil to indicate an error
//       }
    
    var arg: Double = 0
    
    var qtimeDouble = Double(qtime)

    
    var a = courant * qtimeDouble - location
    var b  = ppw - 1.0
    
    var c = a / b
    
    arg = pi * c
    
    
    arg = arg * arg
    
    
    var d = 1.0
    
    var e = 2.0 * arg
    
    var f = d - e
    
   var g = exp(-arg)
    
    
    
    return f * g
    
    
}
