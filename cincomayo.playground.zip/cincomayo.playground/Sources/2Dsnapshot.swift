import Foundation



//func snapshot2d() {
//    var dim1: Float = 0
//    var dim2: Float = 0
//    var filename = ""
//    var temp: Float = 0
//
//
//
//    //fopen(filename, "wb") = FileWriter(FileName: filename)
//
//    //
//
//    filename = "\(basename).\(frame)"
//    frame += 1
//    let fileout = FileWriter(fileName: filename)
//
//    dim1 = Float((endNodeX - startNodeX) / spatialStrideX + 1)
//    dim2 = Float((endNodeY - startNodeY) / spatialStrideY + 1)
//
//
//    fileout.writeFloat(dim1)
//    fileout.writeFloat(dim2)
//
//    for nn in stride(from: endNodeY, through: startNodeY, by: -spatialStrideY) {
//        for mm in stride(from: startNodeX, through: endNodeX, by: spatialStrideX) {
//            temp = Float(Ez[mm, nn])
//            fileout.writeFloat(temp) }
//    }
//
//    fileout.close()
//
//}




// writes data as binary same as schneider document( gnuplot can't read binary)
//public func snapshot2d(qtime: Int) {
//    var dim1: Float = 0
//    var dim2: Float = 0
//    var filename = ""
//    var temp: Float = 0
//
//    filename = "\(basename).\(frame)"
//
//    let fileout = FileWriter(fileName: filename)
//
//    frame += 1
//    // Calculate dim1 and dim2
//    dim1 = Float((endNodeX - startNodeX) / spatialStrideX + 1)
//    dim2 = Float((endNodeY - startNodeY) / spatialStrideY + 1)
//
//    // Convert dim1 and dim2 to binary format
//    var dim1Data = withUnsafeBytes(of: dim1) { Data($0) }
//    var dim2Data = withUnsafeBytes(of: dim2) { Data($0) }
//
//    // Write dim1 and dim2 to file
//   // fileout.writeBinaryData(data: dim1Data)
//   // fileout.writeBinaryData(data: dim2Data)
//
//    // Iterate over grid nodes and write Ez values
////    for nn in stride(from: endNodeY, through: startNodeY, by: -spatialStrideY) {
////        for mm in stride(from: startNodeX, through: endNodeX, by: spatialStrideX) {
////            temp = Float(Ez[mm, nn])
////            var tempData = withUnsafeBytes(of: temp) { Data($0) }
////            fileout.writeBinaryData(data: tempData)
////        }
////    }
//
//
//    for m in 1..<numberOfRows - 1{ // refer to program 8.9
//
//        for n in 1..<numberOfColumns - 1 {
//
//             temp = Float(Ez[m, n])
//                       var tempData = withUnsafeBytes(of: temp) { Data($0) }
//                      fileout.writeBinaryData(data: tempData)
//                    }
//                }
//
//
//
//
//    // Close the file
//    fileout.close()
//}
//




//
//public func snapshot2d(qtime: Int) {
//   // var dim1: Float = 0
//   // var dim2: Float = 0
//
//
//    if (qtime % 30 == 0){
//
//        var filename = ""
//        // var temp: Float = 0
//
//        filename = "\(basename).\(frame)"
//
//        let fileout = FileWriter(fileName: filename)
//
//        frame += 1
//
//
//        var data = " "
//        // Calculate dim1 and dim2
//        // dim1 = Float((endNodeX - startNodeX) / spatialStrideX + 1)
//        //dim2 = Float((endNodeY - startNodeY) / spatialStrideY + 1)
//
//        // Convert dim1 and dim2 to binary format
//        //   var dim1Data = withUnsafeBytes(of: dim1) { Data($0) }
//        // var dim2Data = withUnsafeBytes(of: dim2) { Data($0) }
//
//        // Write dim1 and dim2 to file
//        // fileout.writeBinaryData(data: dim1Data)
//        // fileout.writeBinaryData(data: dim2Data)
//
//        // Iterate over grid nodes and write Ez values
//        //    for nn in stride(from: endNodeY, through: startNodeY, by: -spatialStrideY) {
//        //        for mm in stride(from: startNodeX, through: endNodeX, by: spatialStrideX) {
//        //            temp = Float(Ez[mm, nn])
//        //            var tempData = withUnsafeBytes(of: temp) { Data($0) }
//        //            fileout.writeBinaryData(data: tempData)
//        //        }
//        //    }
//
//
//        for m in 1..<numberOfRows - 1{ // refer to program 8.9
//
//            for n in 1..<numberOfColumns - 1 {
//
//                // data = "\(Ez[m, n])\n"
//
//                data += "\(m) \(n) \(Ez[m, n])\n"
//
//            }
//        }
//
//
//        fileout.write_data(data: data)
//
//    }
//
//}
//


public func snapshot2d(qtime: Int, ez: Grid) {
   // var dim1: Float = 0
   // var dim2: Float = 0
    
    var E = ez
    
   // if (qtime % 30 == 0){
    
    if(qtime % 10 == 0){
        
        var filename = ""
        // var temp: Float = 0
        
        filename = "\(basename).\(frame)"
        
        let fileout = FileWriter(fileName: filename)
        
        frame += 1
        
        
        var data = " "
        // Calculate dim1 and dim2
        // dim1 = Float((endNodeX - startNodeX) / spatialStrideX + 1)
        //dim2 = Float((endNodeY - startNodeY) / spatialStrideY + 1)
        
        // Convert dim1 and dim2 to binary format
        //   var dim1Data = withUnsafeBytes(of: dim1) { Data($0) }
        // var dim2Data = withUnsafeBytes(of: dim2) { Data($0) }
        
        // Write dim1 and dim2 to file
        // fileout.writeBinaryData(data: dim1Data)
        // fileout.writeBinaryData(data: dim2Data)
        
        // Iterate over grid nodes and write Ez values
        //    for nn in stride(from: endNodeY, through: startNodeY, by: -spatialStrideY) {
        //        for mm in stride(from: startNodeX, through: endNodeX, by: spatialStrideX) {
        //            temp = Float(Ez[mm, nn])
        //            var tempData = withUnsafeBytes(of: temp) { Data($0) }
        //            fileout.writeBinaryData(data: tempData)
        //        }
        //    }
        
        
//        for m in 1..<numberOfRows - 1{ // refer to program 8.9
//
//            for n in 1..<numberOfColumns - 1 {
//
//                // data = "\(Ez[m, n])\n"
//
//                data += "\(m) \(n) \(Ez[m, n])\n"
//
//
//            }
//        }
        
        
        for n in stride(from: SizeY - 1, through: 0, by: -1) {
               
            for m in stride(from: 0, through: SizeX - 1, by: 1) {
                
               var EzValue = E[m , n]
            
                    data += "\(m) \(n) \(EzValue)\n"
                }
            }
        
        
        
        fileout.write_data(data: data)
        
   }
    
}

