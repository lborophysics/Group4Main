import Foundation
//
//for m in 0..<numberOfColumns {
//    for n in 0..<numberOfRows - 1{
//        // Hx[m, n] = Chxh[m, n] * Hx[m, n] - Chxe[m, n] * (Ez[m, n + 1] - Ez[m, n])
//        var a = Chxh[m, n] * Hx[m, n]
//        var b = Ez[m, n + 1] - Ez[m, n]
//        var c = Chxe[m, n] * b
//        var d = a - c
//
//        Hx[m, n] = d
//
        
        
        
// func update_electric(ez: inout[Double], hy: [Double], imp0: Double, qTimeSubtract30: Double) {
//            let SIZE = ez.count
//            ez[0] = ez[1]
//            ez[SIZE - 1] = ez[SIZE - 2]
//            for mm in 1..<SIZE {
//                ez[mm] = ceze[mm] * ez[mm] + cezh[mm] * (hy[mm] - hy[mm - 1])
//            }
//            ez[hardwireSourceNode] += exp(-(qTimeSubtract30) * (qTimeSubtract30) / 100.0)
//        }
//
        
        
public func update_hx( hx: inout Grid, ez: Grid) {
    
    for m in 0..<numberOfColumns {
        for n in 0..<numberOfRows - 1{
            // Hx[m, n] = Chxh[m, n] * Hx[m, n] - Chxe[m, n] * (Ez[m, n + 1] - Ez[m, n])
            let a = Chxh[m, n] * hx[m, n]
            let b = ez[m, n + 1] - ez[m, n]
            let c = Chxe[m, n] * b
            let d = a - c
            
            return hx[m, n] = d
        }
    }
}


public func update_hy( hy: inout Grid, ez: Grid) {
    
    for m in 0..<numberOfColumns - 1{
        for n in 0..<numberOfRows {
           // Hy[m, n] = Chyh[m, n] * Hy[m, n] + Chye[m, n] * (Ez[m + 1, n] - Ez[m, n])
            let a = Chyh[m, n] * hy[m, n]
            let b = ez[m + 1, n] - ez[m, n]
            let c = Chye[m , n] * b
            let d = a + c
            
            return   hy[m, n] = d
        }
    }
}



public func update_ez( ez: inout Grid, hy: Grid, hx: Grid, qtime: Int ){
    
    for m in 1..<numberOfColumns - 1{ // refer to program 8.9
        for n in 1..<numberOfRows - 1 {
            // Ez[m, n] = Ceze[m, n] * Ez[m, n] + Cezh[m, n] * ((Hy[m, n] - Hy[m - 1, n]) - (Hx[m, n] - Hx[m, n - 1]))
            let a = Ceze[m, n] * ez[m, n]
            let b = (hy[m, n] - hy[m - 1, n])
            let c = (hx[m, n] - hx[m, n - 1])
            let d = b - c
            let e = Cezh[m, n] * d
            
            return  ez[m, n] = a + e
        }
        
        
        
        
    }
    
  
    
}


