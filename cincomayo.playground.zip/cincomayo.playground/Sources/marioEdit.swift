import Foundation
//
//for m in 0..<numberOfColumns {
//    for n in 0..<numberOfRows - 1{
//        // Hx[m, n] = Chxh[m, n] * Hx[m, n] - Chxe[m, n] * (Ez[m, n + 1] - Ez[m, n])
//        var a = Chxh[m, n] * Hx[m, n]
//        var b = Ez[m, n + 1] - Ez[m, n]
//        var c = Chxe[m, n] * b
//        var d = a - c
//
//        Hx[m, n] = d
//
        
        
        
// func update_electric(ez: inout[Double], hy: [Double], imp0: Double, qTimeSubtract30: Double) {
//            let SIZE = ez.count
//            ez[0] = ez[1]
//            ez[SIZE - 1] = ez[SIZE - 2]
//            for mm in 1..<SIZE {
//                ez[mm] = ceze[mm] * ez[mm] + cezh[mm] * (hy[mm] - hy[mm - 1])
//            }
//            ez[hardwireSourceNode] += exp(-(qTimeSubtract30) * (qTimeSubtract30) / 100.0)
//        }
//
        
        
public func update_hx(Chxh: Grid, Hx: inout Grid, Chxe: Grid, Ez: Grid) {
    
    for m in 0..<numberOfColumns {
        for n in 0..<numberOfRows - 1{
            // Hx[m, n] = Chxh[m, n] * Hx[m, n] - Chxe[m, n] * (Ez[m, n + 1] - Ez[m, n])
            var a = Chxh[m, n] * Hx[m, n]
            var b = Ez[m, n + 1] - Ez[m, n]
            var c = Chxe[m, n] * b
            var d = a - c
            
            return Hx[m, n] = d
        }
    }
}


public func update_hy(Chyh: Grid, Hy: inout Grid, Chye: Grid, Ez: Grid) {
    
    for m in 0..<numberOfColumns - 1{
        for n in 0..<numberOfRows {
           // Hy[m, n] = Chyh[m, n] * Hy[m, n] + Chye[m, n] * (Ez[m + 1, n] - Ez[m, n])
            var a = Chyh[m, n] * Hy[m, n]
            var b = Ez[m + 1, n] - Ez[m, n]
            var c = Chye[m , n] * b
            var d = a + c
            
            return   Hy[m, n] = d
        }
    }
}



public func update_ez(Ceze: Grid, Ez: inout Grid, Cezh: Grid, Hy: Grid, Hx: Grid ){
    
    for m in 1..<numberOfColumns - 1{ // refer to program 8.9
        for n in 1..<numberOfRows - 1 {
            // Ez[m, n] = Ceze[m, n] * Ez[m, n] + Cezh[m, n] * ((Hy[m, n] - Hy[m - 1, n]) - (Hx[m, n] - Hx[m, n - 1]))
            var a = Ceze[m, n] * Ez[m, n]
            var b = (Hy[m, n] - Hy[m - 1, n])
            var c = (Hx[m, n] - Hx[m, n - 1])
            var d = b - c
            var e = Cezh[m, n] * d
            
            return  Ez[m, n] = a + e
        }
    }
    
    //Ez[(numberOfColumns - 1) / 2, (numberOfRows - 1) / 2] = ezINCricker(qtime: qtime, location: 0.0, ppw: 20)
    
}


