import Foundation



public func WaveguideBoundary2D(){
    
    for mm in 20 ... 100{
        for nn in 50 ... 80{
            
            Ez[mm, nn] = 0.0
            
            
        }
        
    }
    
    
    for mm in 20 ... 100{
        for nn in 0 ... 30{
            
            Ez[mm,nn] = 0.0
            
            
        }
    }
    
    
}
