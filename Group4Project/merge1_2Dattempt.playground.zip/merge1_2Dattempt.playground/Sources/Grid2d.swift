import Foundation


public struct twoDGrid {
    let columns: Int // Number of columns
    let rows: Int // Number of rows
    public var data: [[Double]] // Double array

    public init(columns: Int, rows: Int, initialValue: Double) { // Swap columns and rows in the init parameters
        self.columns = columns
        self.rows = rows
        self.data = Array(repeating: Array(repeating: initialValue, count: columns), count: rows) // Nested array
    }

    public subscript(column: Int, row: Int) -> Double { // Swap column and row in the subscript
        get {
            precondition(column >= 0 && column < columns, "Index out of range") // Swap column and row
            precondition(row >= 0 && row < rows, "Index out of range") // Swap column and row
            return data[row][column]
        }
        set {
            precondition(column >= 0 && column < columns, "Index out of range") // Swap column and row
            precondition(row >= 0 && row < rows, "Index out of range") // Swap column and row
            data[row][column] = newValue
        }
    }
}



