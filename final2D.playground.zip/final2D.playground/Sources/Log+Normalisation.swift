import Foundation

public func MaxValue(data: [[Double]]) -> Double {
 
    let flattenedData = data.flatMap{$0}
    
    
    let absValues = flattenedData.map {$0}
    
    
    let maxAbsVal = absValues.max() ?? 0.0
    
 
    
    return maxAbsVal
}



public func MinValue(data: [[Double]]) ->  Double {
    
    let FlattenedData = data.flatMap{$0}
    
    
    let absValues = FlattenedData.map {$0}
    
    let minAbsVal = FlattenedData.min() ?? 0.0
    
 
    
    return minAbsVal
    
    
}




//public func LogNormalise(Real_EzValue: Double, RealMaxvalue: Double, maxNormalisedValue: Double) -> Double{
//
//    let realmin: Double = 10e-3
//
//    let a = Real_EzValue + realmin
//
//    let b = RealMaxvalue + realmin
//
//    let scalefactor = maxNormalisedValue / b
//
//    let logNnormalised_value = a * scalefactor
//
//    let absolute = abs(logNnormalised_value)
//
//    let LOGGED = log10(absolute)
//
//
//
//    return LOGGED
//
//}


//public func LogNormalise(Real_EzValue: Double, RealMaxvalue: Double, maxNormalisedValue: Double) -> Double{
//
//
//
// let a =  Real_EzValue + 1e-9
//
//    let b = a / maxNormalisedValue
//
//    let c = abs(b)
//
//    let d = log10(c)
//
//    return d
//
//}


//public func LogNormalise(Real_EzValue: Double, RealMaxvalue: Double, RealMinvalue: Double, maxNormalisedValue: Double, minNormalisedValue: Double) -> Double{
//
//
//   //let z = (Real_EzValue - RealMinvalue) * (maxNormalisedValue - minNormalisedValue) / (RealMaxvalue - RealMinvalue) + minNormalisedValue
//
//
//    let a = (Real_EzValue - RealMinvalue)
//
//    let b = (maxNormalisedValue - minNormalisedValue)
//
//    let c  = (RealMaxvalue - RealMinvalue)
//
//    let d = a * b
//
//    let e = d / c
//
//
//
//    let f = e + minNormalisedValue
//
//
//    return log10(f)
//
//
//
//
//}
//




public func LogNormalise(Real_EzValue: Double, RealMaxvalue: Double, maxNormalisedValue: Double) -> Double{

    let realmin: Double = 1e-9

    let a = Real_EzValue + realmin

    let b = RealMaxvalue

    let scalefactor = maxNormalisedValue / b

    let c = abs(a * scalefactor)



    let LOGGED = log10(c)



    return LOGGED

}





//public func LogNormalise(Real_EzValue: Double, RealMaxvalue: Double, RealMinvalue: Double, maxNormalisedValue: Double, minNormalisedValue: Double) -> Double{
//
//
//   //let z = (Real_EzValue - RealMinvalue) * (maxNormalisedValue - minNormalisedValue) / (RealMaxvalue - RealMinvalue) + minNormalisedValue
//
//
//
//    let _0a = maxNormalisedValue / RealMaxvalue
//    let _1a = minNormalisedValue / RealMinvalue
//
//
//    let a = (Real_EzValue - RealMinvalue)
//
//
//
//
//
//
//
//    let b = (maxNormalisedValue - minNormalisedValue)
//
//    let c  = (RealMaxvalue - RealMinvalue)
//
//    let d = a * b
//
//    let e = d / c
//
//
//
//    let f = e + minNormalisedValue
//
//
//    return log10(f)
//
//
//
//
//}

//public func LogNormalise(Real_EzValue: Double, RealMaxvalue: Double, RealMinvalue: Double, maxNormalisedValue: Double, minNormalisedValue: Double) -> Double{
//
//
//   //let z = (Real_EzValue - RealMinvalue) * (maxNormalisedValue - minNormalisedValue) / (RealMaxvalue - RealMinvalue) + minNormalisedValue
//
//
//
//   let q = minNormalisedValue + ((Real_EzValue - RealMinvalue) / (RealMaxvalue - RealMinvalue)) * (maxNormalisedValue - minNormalisedValue)
//
//
//    let b = Real_EzValue - RealMinvalue
//
//    let c = RealMaxvalue - RealMinvalue
//
//    let d = maxNormalisedValue - minNormalisedValue
//
//
//    let re = minNormalisedValue + ((b / c) * d)
//
//
//
//    let gol = log10(abs(re))
//
//
//
//
//
////    let b = (maxNormalisedValue - minNormalisedValue)
////
////    let c  = (RealMaxvalue - RealMinvalue)
////
////    let d = a * b
////
////    let e = d / c
////
////
////
////    let f = e + minNormalisedValue
//
//
//    return gol
//
//
//
//
//}
//

//
//public func LogNormalise(Real_EzValue: Double, RealMaxvalue: Double, RealMinvalue: Double, maxNormalisedValue: Double, minNormalisedValue: Double) -> Double{
//
//    var scalefactor: Double = 0.0
//    
//    let _0a = maxNormalisedValue / RealMaxvalue
//    let _1a = minNormalisedValue / RealMinvalue
//    
//    
//    if _0a > abs(_1a) {
//        
//        scalefactor = _0a
//        
//        
//    }
//    
//    else {
//        
//         scalefactor = _1a
//        
//    }
//        
//        
//        
//    
//
//        let realmin: Double = 1e-9
//    
//        let a = Real_EzValue + realmin
//    
//      
//    
//        
//    
//        let c = abs(a * scalefactor)
//    
//    
//    
//        let LOGGED = log10(c)
//    
//    
//    
//        return LOGGED
//    
//
//
//
//
//
//}
// 
