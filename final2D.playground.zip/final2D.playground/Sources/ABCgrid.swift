import Foundation

public struct ABCgrid {
  //  let M: Int
    //let Q: Int
   // let N: Int
    let Size: Int
    
    public var data: [Double] // Double array
    
    public init( Size: Int) { // Swap columns and rows in the init parameters
        
        self.Size = Size
        self.data = Array(repeating: 0.0, count: Size)// Nested array
    }
    
    public subscript(M: Int, Q: Int, N: Int) -> Double { // Swap column and row in the subscript
        get {
            
            return data[N * 6 + Q * 3 + M]
        }
        set {
           
            data[N * 6 + Q * 3 + M] = newValue
        }
    }
}
