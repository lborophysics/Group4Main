import Foundation





public func snapshot2d(qtime: Int, ez: Grid) {
   
    
  let E = ez
   var maxvalue = MaxValue(data: ez.data)

    var minvalue = MinValue(data: ez.data)
    
   // if (qtime % 30 == 0){
    
    if(qtime % 10 == 0){
        
        var filename = ""
        
        
        filename = "\(basename).\(frame)"
        
        let fileout = FileWriter(fileName: filename)
        
        frame += 1
        
        
        var data = " "

        
        for n in stride(from: SizeY - 1, through: 0, by: -1) {
               
            for m in stride(from: 0, through: SizeX - 1, by: 1) {
                
               let EzValue = E[m , n]
                
              
              // let LogNorm_value = LogNormalise(Real_EzValue: EzValue, RealMaxvalue: maxvalue, RealMinvalue: minvalue, maxNormalisedValue: 2, minNormalisedValue: 10e-3)
                
                let LogNorm_value = LogNormalise(Real_EzValue: EzValue, RealMaxvalue: maxvalue, maxNormalisedValue: 3)
                
                
                
                
                
                
                
                
                
                
            
                    data += "\(m) \(n) \(LogNorm_value)\n"
                }
            }
        
        
        
        fileout.write_data(data: data)
        
   }
    
}

