import Foundation

//let MaxTime = 150
let SizeX = 101
let SizeY = 81
var Time: Int = 0

var temporalStride = 10
var frame: Int = 0
var startTime = 10
var startNodeX = 0
var endNodeX = 101
var spatialStrideX = 1
var startNodeY = 0
var endNodeY = 81
var spatialStrideY = 1


let basename = "snapshot"

let numberOfRows = 81

let numberOfColumns = 101

let courant = 1.0

let imp0 = 377.0

let pi = Double.pi


public var Ez = Grid(columns: numberOfColumns, rows: numberOfRows, initialValue: 0.0)

public var Hx = Grid(columns: numberOfColumns , rows: numberOfRows - 1, initialValue: 0.0)

public var Hy = Grid(columns: numberOfColumns - 1, rows: numberOfRows , initialValue: 0.0)


public var Chxe = Grid(columns: numberOfColumns , rows: numberOfRows - 1, initialValue: 0.0)

public var Chye = Grid(columns: numberOfColumns - 1, rows: numberOfRows , initialValue: 0.0)

public var Ceze = Grid(columns: numberOfColumns, rows: numberOfRows, initialValue: 0.0)



public var Chxh = Grid(columns: numberOfColumns , rows: numberOfRows - 1, initialValue: 0.0)

public var Chyh = Grid(columns: numberOfColumns - 1, rows: numberOfRows, initialValue: 0.0)

public var Cezh = Grid(columns: numberOfColumns, rows: numberOfRows, initialValue: 0.0)

var firstX: Int = 0
var firstY: Int = 0
var lastX: Int = 0
var lastY: Int = 0
