import Foundation

public struct auxillaryGrid{
    
    
    
    
    
    
}
