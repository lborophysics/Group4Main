import Foundation


/* Initialization function for first-order ABC. */
//
//var temp: Double
//
//
//
//    /* Calculate coefficient on left end of grid */
//    temp = sqrt(Cezh(0) * Chye(0))
//    abcCoefLeft = (temp - 1.0) / (temp + 1.0)
//
//    /* Calculate coefficient on right end of grid */
//    temp = sqrt(Cezh(SizeX - 1) * Chye(SizeX - 2))
//    abcCoefRight = (temp - 1.0) / (temp + 1.0)
//
//
//
///* First-order ABC. */
//func abc(g: Grid) {
//    /* Check if abcInit() has been called */
//    guard initDone else {
//        fatalError("abc: abcInit must be called before abc.")
//    }
//
//    /* ABC for left side of grid */
//    Ez[0] = ezOldLeft + abcCoefLeft * (Ez[1] - Ez[0])
//    ezOldLeft = Ez[1]
//
//    /* ABC for right side of grid */
//    Ez[SizeX - 1] = ezOldRight + abcCoefRight * (Ez[SizeX - 2] - Ez[SizeX - 1])
//    ezOldRight = Ez[SizeX - 2]
//}
//







// 2nd order ABC
//var initDone = false
//var abcCoefLeft = [0.0, 0.0, 0.0]
//var abcCoefRight = [0.0, 0.0, 0.0]
//var ezOldLeft1 = [0.0, 0.0, 0.0]
//var ezOldLeft2 = [0.0, 0.0, 0.0]
//var ezOldRight1 = [0.0, 0.0, 0.0]
//var ezOldRight2 = [0.0, 0.0, 0.0]
//
///* Calculate coefficients on left end of grid */
//func calculateCoefficientsLeft() {
//    let temp1 = sqrt(Cezh[0] * Chye[0])
//    let temp2 = 1.0 / temp1 + 2.0 + temp1
//    abcCoefLeft[0] = -(1.0 / temp1 - 2.0 + temp1) / temp2
//    abcCoefLeft[1] = -2.0 * (temp1 - 1.0 / temp1) / temp2
//    abcCoefLeft[2] = 4.0 * (temp1 + 1.0 / temp1) / temp2
//}
//
///* Calculate coefficients on right end of grid */
//func calculateCoefficientsRight() {
//    let temp1 = sqrt(Cezh(SizeX - 1) * Chye(SizeX - 2))
//    let temp2 = 1.0 / temp1 + 2.0 + temp1
//    abcCoefRight[0] = -(1.0 / temp1 - 2.0 + temp1) / temp2
//    abcCoefRight[1] = -2.0 * (temp1 - 1.0 / temp1) / temp2
//    abcCoefRight[2] = 4.0 * (temp1 + 1.0 / temp1) / temp2
//}
//
//


/* Initialization function for second-order ABC */
//func abcInit() {
//    initDone = true
//    calculateCoefficientsLeft()
//    calculateCoefficientsRight()
//}

/* Second-order ABC */
//func abc(g: Grid) {
//    var mm: Int
//
//    /* Check if abcInit() has been called */
//    guard initDone else {
//        fatalError("abc: abcInit must be called before abc.")
//    }
//
//    /* ABC for left side of grid */
//    Ez[0] = abcCoefLeft[0] * (Ez[2] + ezOldLeft2[0])
//           + abcCoefLeft[1] * (ezOldLeft1[0] + ezOldLeft1[2] - Ez[1] - ezOldLeft2[1])
//           + abcCoefLeft[2] * ezOldLeft1[1] - ezOldLeft2[2]
//
//    /* ABC for right side of grid */
//    Ez[SizeX - 1] = abcCoefRight[0] * (Ez[SizeX - 3] + ezOldRight2[0])
//                  + abcCoefRight[1] * (ezOldRight1[0] + ezOldRight1[2] - Ez[SizeX - 2] - ezOldRight2[1])
//                  + abcCoefRight[2] * ezOldRight1[1] - ezOldRight2[2]
//
//    /* Update stored fields */
//    for mm in 0..<3 {
//        ezOldLeft2[mm] = ezOldLeft1[mm]
//        ezOldLeft1[mm] = Ez[mm]
//        ezOldRight2[mm] = ezOldRight1[mm]
//        ezOldRight1[mm] = Ez[SizeX - 1 - mm]
//    }
//}

