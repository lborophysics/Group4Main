import Foundation

//TfSFUpdste( initialisation of 1D auxillary(correct) grid is within here

//public func TFSF_Update(HY: Grid, CHYE: Grid)

//
//var mm = firstX - 1
//for nn in firstY...lastY {
//    Hy[mm][nn] -= Chye(mm, nn) * Ez(g1, mm + 1)
//}
//
//// Correct Hy along right edge
//mm = lastX
//for nn in firstY...lastY {
//    Hy[mm][nn] += Chye(mm, nn) * Ez1G(g1, mm)
//}
//
//// Correct Hx along bottom
//var nn = firstY - 1
//for mm in firstX...lastX {
//    Hx[mm][nn] += Chxe(mm, nn) * Ez1G(g1, mm)
//}
//
//// Correct Hx along top
//nn = lastY
//for mm in firstX...lastX {
//    Hx[mm][nn] -= Chxe(mm, nn) * Ez1G(g1, mm)
//}
//
////updateH2d(g1) // Update 1D
////updateE2d(g1) // Update 1D
//Ez1G(g1, 0) = ezInc(TimeG(g1)) // Set source node
//TimeG(g1) += 1
//
//// Correct Ez along left edge
//mm = firstX
//for nn in firstY...lastY {
//    Ez[mm][nn] -= Cezh(mm, nn) * Hy1G(g1, mm - 1)
//}
//
//// Correct Ez along right edge
//mm = lastX
//for nn in firstY...lastY {
//    Ez[mm][nn] += Cezh(mm, nn) * Hy1G(g1, mm)
//}
//
//return
//
//====================================================
