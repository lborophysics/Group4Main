import Cocoa

var qtime = 0
var MaxTime = 300

let numberOfRows = 81

let numberOfColumns = 101

let courant = 1.0 / sqrt(2)

let imp0 = 377.0

let pi = Double.pi


// TFSF region
let firstX = 5
let firstY = 5
let lastX = 95
let lastY = 75
//var lastY: Int = 0

var coef0: Double = 0.0
var coef1: Double = 0.0
var coef2: Double = 0.0

var Time: Int = 0


// constants needed for 1D aux
let Nloss = 20
let MaxLoss = 0.35

var Xsize = 101

Xsize += Nloss








//ABC funcitons + Variables initialisations

//func EzLeft(_ m: Int, _ q: Int, _ n: Int, _ ezLeft: [Double]) -> Double {
//    return ezLeft[n * 6 + q * 3 + m]
//}
//
//func EzRight(_ m: Int, _ q: Int, _ n: Int, _ ezRight: [Double]) -> Double {
//    return ezRight[n * 6 + q * 3 + m]
//}
//
//func EzTop(_ n: Int, _ q: Int, _ m: Int, _ ezTop: [Double]) -> Double {
//    return ezTop[m * 6 + q * 3 + n]
//}
//
//func EzBottom(_ n: Int, _ q: Int, _ m: Int, _ ezBottom: [Double]) -> Double {
//    return ezBottom[m * 6 + q * 3 + n]
//}


//var ezLeft = Array(repeating: 0.0, count: (numberOfRows - 1) * 6)
//var ezRight = Array(repeating: 0.0, count: (numberOfRows - 1) * 6)
//var ezTop = Array(repeating: 0.0, count: (numberOfColumns - 1) * 6)
//var ezBottom = Array(repeating: 0.0, count: (numberOfColumns - 1) * 6)





var EzLeft = ABCgrid(Size: (numberOfRows) * 6)
var EzRight = ABCgrid(Size: (numberOfRows ) * 6)
var EzTop = ABCgrid(Size: (numberOfColumns ) * 6)
var EzBottom = ABCgrid(Size: (numberOfColumns ) * 6)



// INitialise auxillary 1D========


var Hy1DAux = Array(repeating: 0.0, count: Xsize - 1)
var Chyh1Daux = Array(repeating: 0.0, count: Xsize - 1)
var Chye1Daux = Array(repeating: 0.0, count: Xsize - 1)

var Ez1Daux = Array(repeating: 0.0, count: Xsize)
var Ceze1Daux = Array(repeating: 0.0, count: Xsize)
var Cezh1Daux = Array(repeating: 0.0, count: Xsize)





// UPDATE COEFFICIENTS 2D GRID==================== correct


    
    
    
let courantximp = courant * imp0
    
let courantDIVimp = courant / imp0
    
UpdateElectricMagenticCoefficients(courantDIVimp: courantDIVimp, courantximp: courantximp)
  
    
// update coeficients 1D GRID================= correct


for mm in 0..<Xsize - 1 {
    
    if mm < (Xsize - 1 - Nloss){
        Ceze1Daux[mm] = 1.0
        Cezh1Daux[mm] = courantximp
        Chyh1Daux[mm] = 1.0
        Chye1Daux[mm] = courantDIVimp
        
    }
    
    else {
        
        
        let a  = Double(Xsize) - 1.0 - Double(Nloss)
        var dephtInLayer = Double(mm) - Double((a)) + 0.5
        let b = dephtInLayer / Double(Nloss)
        var lossFactor = MaxLoss * pow(b,2)
        
        let c = 1.0 - lossFactor
        let d = 1.0 + lossFactor
        
        Ceze1Daux[mm] = c / d
        Cezh1Daux[mm] = courantximp / d
        
        dephtInLayer += 0.5
        
        let e = dephtInLayer / Double(Nloss)
        
        lossFactor =  MaxLoss * pow(e, 2)
        
        let f = 1.0 - lossFactor
        let g = 1.0 + lossFactor
        
        Chyh1Daux[mm] = f / g
        Chye1Daux[mm] = courantDIVimp / g
        
        
    }
}



//================END OF INITIALISATIONS==================================
    

//Updating Electric and Magnetic

for qtime in 0..<MaxTime {
    updateElectricMagnetic2D(qtime: qtime)
}
    
    
    
//INERT TFSF UPDATE EQUATIONS:

//
    //Insert corrections in Hy and hx

        // Correct Hy along left edge
            
            for nnn in firstY...lastY {
                
                let mmm = firstX - 1
                
                
                Hy[mmm,nnn] -= Chye[mmm, nnn] * Ez1Daux[mmm + 1]
            }



        // Correct Hy along right edge
            
            for nnn in firstY...lastY {
                
                let mmm = lastX
                
                Hy[mmm,nnn] += Chye[mmm, nnn] * Ez1Daux[mmm]
            }


        // Correct Hx along bottom
         
                for mm in firstX...lastX {
                  
                    let nnn = firstY - 1
                    
                    
                    
                Hx[mm,nnn] += Chxe[mm, nnn] * Ez1Daux[mm]
                }


        // Correct Hx along top
            
                for mm in firstX...lastX {
                    
                   let nnn = lastY
                    
            Hx[mm,nnn] -= Chxe[mm, nnn] * Ez1Daux[mm]
            }




                // update auxillary 1D

                  //  Hy1DAux[Xsize - 1] = Hy1DAux[Xsize - 2]
                    //1d HY
                    for mm in 0..<(Xsize - 1) {
                        Hy1DAux[mm] = Chyh1Daux[mm] * Hy1DAux[mm] + Chye1Daux[mm] * (Ez1Daux[mm + 1] - Ez1Daux[mm])
                    }

                    Ez1Daux[Xsize - 1] = Ez1Daux[Xsize - 2] //simple ABC auxillarynode rhs as required pg 207
                    //Ez1Daux[0] = Ez1Daux[1]

                    //1d hx
                    for mm in 1..<(Xsize - 1) {
                        Ez1Daux[mm] = Ceze1Daux[mm] * Ez1Daux[mm] + Cezh1Daux[mm] * (Hy1DAux[mm] - Hy1DAux[mm - 1])
                    }



                   // Ez1Daux[0] = ezINCricker(qtime: Time, location: 0.0, ppw: 30)// Set source node
                   // Time += 1
                let qTimeSubtract30 = Double(qtime) - 30.0

    Ez1Daux[0] = exp(-(qTimeSubtract30) * (qTimeSubtract30) / 100.0)




  // //  insert corrections in ez
       
         //Correct Ez along left edge
        
        for nn in firstY...lastY {

        let mm = firstX


            Ez[mm,nn] -= Cezh[mm, nn] * Hy1DAux[mm - 1]
        }



        // Correct Ez along right edge

        for nn in firstY...lastY {

            let  mm = lastX

            Ez[mm, nn] += Cezh[mm, nn] * Hy1DAux[mm]
        }



    
    
    
    
    
    

    
    
    
    
//Update EZ 2D: correct
    
    
    
    
    for m in 1..<numberOfColumns - 1{
        
        for n in 1..<numberOfRows - 1 {
            
           // Ez[m, n] = Ceze[m, n] * Ez[m, n] + Cezh[m, n] * ((Hy[m, n] - Hy[m - 1, n]) - (Hx[m, n] - Hx[m, n - 1]))
            
            
            var a = Ceze[m, n] * Ez[m, n]
            
            var b = (Hy[m, n] - Hy[m - 1, n])
            
            var c = (Hx[m, n] - Hx[m, n - 1])
            
            var d = b - c
            
            var e = Cezh[m, n] * d
            
            
            
            Ez[m, n] = a + e
            
            
            
        }
    }


//
    //PECWAll / waveguide
//    for nn in 50 ... 80{   // 75
//
//            Ez[20, nn] = 0.0
//
//        }
//
//    for nn in 0 ... 30{ //5
//
//        Ez[20,nn] = 0.0
//
//    }
    
    for mm in 20 ... 100{
        for nn in 50 ... 80{
            
            Ez[mm, nn] = 0.0
            
            
        }
        
    }
    
    
    for mm in 20 ... 100{
        for nn in 0 ... 30{
            
            Ez[mm,nn] = 0.0
            
            
        }
    }
    
    
//
//
//    for mm in 20 ... 95{
//
//        Ez[mm, 30] = 0.0
//
//    }

    
    

            
//Ez[(numberOfColumns - 1) / 2, (numberOfRows - 1) / 2] = ezINCricker(qtime: qtime, location: 0.0, ppw: 20)



//    
//    
//    
//    
//    
//INSERT ABC FUNCTION:


//// correct
        var temp1 = sqrt(Cezh[0,0] * Chye[0,0])
        var temp2 = 1.0 / temp1 + 2.0 + temp1
        coef0 = -(1.0 / temp1 - 2.0 + temp1) / temp2
        coef1 = -2.0 * (temp1 - 1.0 / temp1) / temp2
        coef2 = 4.0 * (temp1 + 1.0 / temp1) / temp2
//
//
//
//
//
//        //ABC LEFT
        for nn in 0..<numberOfRows {
                var subExpr1 = Ez[2, nn] + EzLeft[0, 1, nn]
                var subExpr2 = EzLeft[0, 0, nn] + EzLeft[2, 0, nn]
                var subExpr3 = Ez[1, nn]
                var subExpr4 = EzLeft[1, 1, nn]
                var subExpr5 = coef2 * EzLeft[1, 0, nn] - EzLeft[2, 1, nn]

                Ez[0, nn] = coef0 * subExpr1 + coef1 * (subExpr2 - subExpr3 - subExpr4) + subExpr5


                // Memorize old fields
                    for mm in 0..<3 {

                        EzLeft[mm,1,nn] = EzLeft[mm,0,nn]
                        EzLeft[mm,0,nn] = Ez[mm, nn]
                    }
            }

//
//
//
//
        //ABCRIGHT
        for nn in 0..<numberOfRows {
            //Ez[numberOfColumns - 1,nn] = coef0 * (Ez[numberOfColumns - 3,nn] + EzRight(0, 1, nn, ezRight)) + coef1 * (EzRight(0, 0, nn, ezRight) + EzRight(2, 0, nn, ezRight) - Ez[numberOfColumns - 2,nn] - EzRight(1, 1, nn, ezRight)) + coef2 * EzRight(1, 0, nn, ezRight) - EzRight(2, 1, nn, ezRight)


            var A = Ez[numberOfColumns - 3,nn] + EzRight[0, 1, nn]
            var B = coef0 * A

            var C = EzRight[0, 0, nn] + EzRight[2, 0, nn] - Ez[numberOfColumns - 2,nn] - EzRight[1, 1, nn]

            var D = coef1 * C

            var E = coef2 * EzRight[1, 0, nn]

            Ez[numberOfColumns - 1,nn] = B + D + E - EzRight[2, 1, nn]

                // Memorize old fields
                    for mm in 0..<3 {
                        EzRight[mm,1,nn] = EzRight[mm,0,nn]
                        EzRight[mm,0,nn] = Ez[numberOfColumns - 1 - mm,nn]
                    }
        }








        //ABC BOTTOM
        for mm in 0..<numberOfColumns {


            var a =  Ez[mm, 2] + EzBottom[0, 1, mm]
            var b = EzBottom[0,0,mm] + EzBottom[2,0,mm] - Ez[mm,1] - EzBottom[1,1,mm]
            var d = coef0 * a
            
            
            var c = coef2 * EzBottom[1,0,mm]
            
            var e = coef1 * b




            Ez[mm, 0] = d + e + c - EzBottom[2,1,mm]

                    // Memorize old fields
                for nn in 0..<3 {

                        EzBottom[nn,1,mm] = EzBottom[nn,0,mm]
                        EzBottom[nn,0,mm] = Ez[mm, nn]
                }
        }








        // ABC TOP
        for mm in 0..<numberOfColumns {
            let subExpr1 = Ez[mm, numberOfRows - 3] + EzTop[0, 1, mm]
            let subExpr2 = EzTop[0, 0, mm] + EzTop[2, 0, mm] - Ez[mm, numberOfRows - 2] - EzTop[1, 1, mm]
            let subExpr4 = coef2 * EzTop[1, 0, mm]
            
            let subExpr5 = EzTop[2, 1, mm]

            Ez[mm, numberOfRows - 1] = coef0 * (subExpr1) + coef1 * (subExpr2) + subExpr4 - subExpr5

                // Memorize old fields
                    for nn in 0..<3 {

                        EzTop[nn,1,mm] = EzTop[nn,0,mm]
                        EzTop[nn,0,mm] = Ez[mm, numberOfRows - 1 - nn]
                }
           }


    
    
    
    
    snapshot2d(qtime: qtime, ez: Ez)

   
}



