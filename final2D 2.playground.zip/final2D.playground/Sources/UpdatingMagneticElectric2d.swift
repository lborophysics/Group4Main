import Foundation

public func updateElectricMagnetic2D(qtime: Int)
{
    //UPDATE HX 2D: correct
    for m in 0..<numberOfColumns { //101

        for n in 0..<numberOfRows - 1{ //80

            // Hx[m, n] = Chxh[m, n] * Hx[m, n] - Chxe[m, n] * (Ez[m, n + 1] - Ez[m, n])


            var a = Chxh[m, n] * Hx[m, n]

            var b = Ez[m, n + 1] - Ez[m, n]

            var c = Chxe[m, n] * b

            var d = a - c




            Hx[m, n] = d
        }
    }
    
    //UPDATE HY 2D: correct
    for m in 0..<numberOfColumns - 1{ //100
        
        for n in 0..<numberOfRows {//81
            
           // Hy[m, n] = Chyh[m, n] * Hy[m, n] + Chye[m, n] * (Ez[m + 1, n] - Ez[m, n])
            
            
            var a = Chyh[m, n] * Hy[m, n]
            
            var b = Ez[m + 1, n] - Ez[m, n]
            
            var c = Chye[m , n] * b
            
            var d = a + c
            
            
            Hy[m, n] = d
            
            
            
        }
    }
}
